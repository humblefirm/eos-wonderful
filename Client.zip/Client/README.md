dApp Client - Software Developement Toolkit
======

이오스원더풀 기반의 댑을 만들기 위한 Client SDK 입니다.
키를 생성하고 다루거나, SA와 통신하여 트랜잭션을 발행하기 위한 시그니쳐 관련 함수들이 정리돼있습니다.


## 설명
작성중입니다.